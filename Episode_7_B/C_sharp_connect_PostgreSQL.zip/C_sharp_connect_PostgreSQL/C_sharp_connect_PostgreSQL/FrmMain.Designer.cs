﻿namespace C_sharp_connect_PostgreSQL
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this._Close = new System.Windows.Forms.ToolStripMenuItem();
            this._Max_Min = new System.Windows.Forms.ToolStripMenuItem();
            this._File = new System.Windows.Forms.ToolStripMenuItem();
            this._Pos = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this._Style = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menuStrip1.BackgroundImage")));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._Close,
            this._Max_Min,
            this._File});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1184, 26);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // _Close
            // 
            this._Close.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._Close.Image = ((System.Drawing.Image)(resources.GetObject("_Close.Image")));
            this._Close.Name = "_Close";
            this._Close.Size = new System.Drawing.Size(28, 22);
            this._Close.Click += new System.EventHandler(this._Close_Click);
            // 
            // _Max_Min
            // 
            this._Max_Min.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._Max_Min.Image = ((System.Drawing.Image)(resources.GetObject("_Max_Min.Image")));
            this._Max_Min.Name = "_Max_Min";
            this._Max_Min.Size = new System.Drawing.Size(28, 22);
            this._Max_Min.Click += new System.EventHandler(this._Max_Min_Click);
            // 
            // _File
            // 
            this._File.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._Pos});
            this._File.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._File.Image = ((System.Drawing.Image)(resources.GetObject("_File.Image")));
            this._File.Name = "_File";
            this._File.Size = new System.Drawing.Size(68, 22);
            this._File.Text = "&File";
            // 
            // _Pos
            // 
            this._Pos.Image = ((System.Drawing.Image)(resources.GetObject("_Pos.Image")));
            this._Pos.Name = "_Pos";
            this._Pos.Size = new System.Drawing.Size(100, 22);
            this._Pos.Text = "POS";
            this._Pos.Click += new System.EventHandler(this._Pos_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // _Style
            // 
            this._Style.ElipseRadius = 15;
            this._Style.TargetControl = this;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 761);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmMain";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem _Close;
        private System.Windows.Forms.ToolStripMenuItem _Max_Min;
        private System.Windows.Forms.ToolStripMenuItem _File;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private Bunifu.Framework.UI.BunifuElipse _Style;
        private System.Windows.Forms.ToolStripMenuItem _Pos;
    }
}