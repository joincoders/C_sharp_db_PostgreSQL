﻿namespace C_sharp_connect_PostgreSQL
{
    partial class FrmDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDashboard));
            this.itemPanel1 = new DevComponents.DotNetBar.ItemPanel();
            this.metroTileItem1 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem2 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem3 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem4 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem5 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem6 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem7 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem8 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.metroTileItem9 = new DevComponents.DotNetBar.Metro.MetroTileItem();
            this.digitalClock1 = new DigitalClock.DigitalClock();
            this.itemPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // itemPanel1
            // 
            this.itemPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            // 
            // 
            // 
            this.itemPanel1.BackgroundStyle.Class = "ItemPanel";
            this.itemPanel1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemPanel1.ContainerControlProcessDialogKey = true;
            this.itemPanel1.Controls.Add(this.digitalClock1);
            this.itemPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.itemPanel1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.metroTileItem1,
            this.metroTileItem2,
            this.metroTileItem3,
            this.metroTileItem4,
            this.metroTileItem5,
            this.metroTileItem6,
            this.metroTileItem7,
            this.metroTileItem8,
            this.metroTileItem9});
            this.itemPanel1.ItemSpacing = 5;
            this.itemPanel1.Location = new System.Drawing.Point(0, 0);
            this.itemPanel1.MultiLine = true;
            this.itemPanel1.Name = "itemPanel1";
            this.itemPanel1.Size = new System.Drawing.Size(743, 325);
            this.itemPanel1.TabIndex = 0;
            this.itemPanel1.Text = "itemPanel1";
            // 
            // metroTileItem1
            // 
            this.metroTileItem1.Image = ((System.Drawing.Image)(resources.GetObject("metroTileItem1.Image")));
            this.metroTileItem1.Name = "metroTileItem1";
            this.metroTileItem1.Text = "Point Of Sale";
            this.metroTileItem1.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Blue;
            // 
            // 
            // 
            this.metroTileItem1.TileStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(102)))), ((int)(((byte)(168)))));
            this.metroTileItem1.TileStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(91)))), ((int)(((byte)(120)))), ((int)(((byte)(190)))));
            this.metroTileItem1.TileStyle.BackColorGradientAngle = 45;
            this.metroTileItem1.TileStyle.Class = "";
            this.metroTileItem1.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem1.TileStyle.PaddingBottom = 4;
            this.metroTileItem1.TileStyle.PaddingLeft = 4;
            this.metroTileItem1.TileStyle.PaddingRight = 4;
            this.metroTileItem1.TileStyle.PaddingTop = 4;
            this.metroTileItem1.TileStyle.TextColor = System.Drawing.Color.White;
            // 
            // metroTileItem2
            // 
            this.metroTileItem2.Image = ((System.Drawing.Image)(resources.GetObject("metroTileItem2.Image")));
            this.metroTileItem2.Name = "metroTileItem2";
            this.metroTileItem2.Text = "Store";
            this.metroTileItem2.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Magenta;
            // 
            // 
            // 
            this.metroTileItem2.TileStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(85)))), ((int)(((byte)(148)))));
            this.metroTileItem2.TileStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(98)))), ((int)(((byte)(185)))));
            this.metroTileItem2.TileStyle.BackColorGradientAngle = 45;
            this.metroTileItem2.TileStyle.Class = "";
            this.metroTileItem2.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem2.TileStyle.PaddingBottom = 4;
            this.metroTileItem2.TileStyle.PaddingLeft = 4;
            this.metroTileItem2.TileStyle.PaddingRight = 4;
            this.metroTileItem2.TileStyle.PaddingTop = 4;
            this.metroTileItem2.TileStyle.TextColor = System.Drawing.Color.White;
            // 
            // metroTileItem3
            // 
            this.metroTileItem3.Image = ((System.Drawing.Image)(resources.GetObject("metroTileItem3.Image")));
            this.metroTileItem3.Name = "metroTileItem3";
            this.metroTileItem3.Text = "Customer";
            this.metroTileItem3.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Coffee;
            // 
            // 
            // 
            this.metroTileItem3.TileStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(76)))), ((int)(((byte)(41)))));
            this.metroTileItem3.TileStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(67)))), ((int)(((byte)(37)))));
            this.metroTileItem3.TileStyle.BackColorGradientAngle = 45;
            this.metroTileItem3.TileStyle.Class = "";
            this.metroTileItem3.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem3.TileStyle.PaddingBottom = 4;
            this.metroTileItem3.TileStyle.PaddingLeft = 4;
            this.metroTileItem3.TileStyle.PaddingRight = 4;
            this.metroTileItem3.TileStyle.PaddingTop = 4;
            this.metroTileItem3.TileStyle.TextColor = System.Drawing.Color.White;
            // 
            // metroTileItem4
            // 
            this.metroTileItem4.Image = ((System.Drawing.Image)(resources.GetObject("metroTileItem4.Image")));
            this.metroTileItem4.Name = "metroTileItem4";
            this.metroTileItem4.Text = "History";
            this.metroTileItem4.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Olive;
            // 
            // 
            // 
            this.metroTileItem4.TileStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(187)))), ((int)(((byte)(17)))));
            this.metroTileItem4.TileStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(176)))), ((int)(((byte)(16)))));
            this.metroTileItem4.TileStyle.BackColorGradientAngle = 45;
            this.metroTileItem4.TileStyle.Class = "";
            this.metroTileItem4.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem4.TileStyle.PaddingBottom = 4;
            this.metroTileItem4.TileStyle.PaddingLeft = 4;
            this.metroTileItem4.TileStyle.PaddingRight = 4;
            this.metroTileItem4.TileStyle.PaddingTop = 4;
            this.metroTileItem4.TileStyle.TextColor = System.Drawing.Color.White;
            // 
            // metroTileItem5
            // 
            this.metroTileItem5.Image = ((System.Drawing.Image)(resources.GetObject("metroTileItem5.Image")));
            this.metroTileItem5.Name = "metroTileItem5";
            this.metroTileItem5.Text = "New product";
            this.metroTileItem5.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Green;
            // 
            // 
            // 
            this.metroTileItem5.TileStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(151)))), ((int)(((byte)(42)))));
            this.metroTileItem5.TileStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(177)))), ((int)(((byte)(51)))));
            this.metroTileItem5.TileStyle.BackColorGradientAngle = 45;
            this.metroTileItem5.TileStyle.Class = "";
            this.metroTileItem5.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem5.TileStyle.PaddingBottom = 4;
            this.metroTileItem5.TileStyle.PaddingLeft = 4;
            this.metroTileItem5.TileStyle.PaddingRight = 4;
            this.metroTileItem5.TileStyle.PaddingTop = 4;
            this.metroTileItem5.TileStyle.TextColor = System.Drawing.Color.White;
            // 
            // metroTileItem6
            // 
            this.metroTileItem6.Image = ((System.Drawing.Image)(resources.GetObject("metroTileItem6.Image")));
            this.metroTileItem6.Name = "metroTileItem6";
            this.metroTileItem6.Text = "Purchase";
            this.metroTileItem6.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Default;
            // 
            // 
            // 
            this.metroTileItem6.TileStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(83)))), ((int)(((byte)(117)))));
            this.metroTileItem6.TileStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(103)))), ((int)(((byte)(155)))));
            this.metroTileItem6.TileStyle.BackColorGradientAngle = 45;
            this.metroTileItem6.TileStyle.Class = "";
            this.metroTileItem6.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem6.TileStyle.PaddingBottom = 4;
            this.metroTileItem6.TileStyle.PaddingLeft = 4;
            this.metroTileItem6.TileStyle.PaddingRight = 4;
            this.metroTileItem6.TileStyle.PaddingTop = 4;
            this.metroTileItem6.TileStyle.TextColor = System.Drawing.Color.White;
            // 
            // metroTileItem7
            // 
            this.metroTileItem7.Image = ((System.Drawing.Image)(resources.GetObject("metroTileItem7.Image")));
            this.metroTileItem7.Name = "metroTileItem7";
            this.metroTileItem7.Text = "Supply";
            this.metroTileItem7.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Orange;
            // 
            // 
            // 
            this.metroTileItem7.TileStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(131)))), ((int)(((byte)(0)))));
            this.metroTileItem7.TileStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(136)))), ((int)(((byte)(0)))));
            this.metroTileItem7.TileStyle.BackColorGradientAngle = 45;
            this.metroTileItem7.TileStyle.Class = "";
            this.metroTileItem7.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem7.TileStyle.PaddingBottom = 4;
            this.metroTileItem7.TileStyle.PaddingLeft = 4;
            this.metroTileItem7.TileStyle.PaddingRight = 4;
            this.metroTileItem7.TileStyle.PaddingTop = 4;
            this.metroTileItem7.TileStyle.TextColor = System.Drawing.Color.White;
            // 
            // metroTileItem8
            // 
            this.metroTileItem8.Image = ((System.Drawing.Image)(resources.GetObject("metroTileItem8.Image")));
            this.metroTileItem8.Name = "metroTileItem8";
            this.metroTileItem8.Text = "Setting";
            this.metroTileItem8.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.Coffee;
            // 
            // 
            // 
            this.metroTileItem8.TileStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(76)))), ((int)(((byte)(41)))));
            this.metroTileItem8.TileStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(67)))), ((int)(((byte)(37)))));
            this.metroTileItem8.TileStyle.BackColorGradientAngle = 45;
            this.metroTileItem8.TileStyle.Class = "";
            this.metroTileItem8.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem8.TileStyle.PaddingBottom = 4;
            this.metroTileItem8.TileStyle.PaddingLeft = 4;
            this.metroTileItem8.TileStyle.PaddingRight = 4;
            this.metroTileItem8.TileStyle.PaddingTop = 4;
            this.metroTileItem8.TileStyle.TextColor = System.Drawing.Color.White;
            // 
            // metroTileItem9
            // 
            this.metroTileItem9.Image = ((System.Drawing.Image)(resources.GetObject("metroTileItem9.Image")));
            this.metroTileItem9.Name = "metroTileItem9";
            this.metroTileItem9.Text = "Report";
            this.metroTileItem9.TileColor = DevComponents.DotNetBar.Metro.eMetroTileColor.RedViolet;
            // 
            // 
            // 
            this.metroTileItem9.TileStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(0)))), ((int)(((byte)(70)))));
            this.metroTileItem9.TileStyle.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(0)))), ((int)(((byte)(61)))));
            this.metroTileItem9.TileStyle.BackColorGradientAngle = 45;
            this.metroTileItem9.TileStyle.Class = "";
            this.metroTileItem9.TileStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.metroTileItem9.TileStyle.PaddingBottom = 4;
            this.metroTileItem9.TileStyle.PaddingLeft = 4;
            this.metroTileItem9.TileStyle.PaddingRight = 4;
            this.metroTileItem9.TileStyle.PaddingTop = 4;
            this.metroTileItem9.TileStyle.TextColor = System.Drawing.Color.White;
            // 
            // digitalClock1
            // 
            this.digitalClock1.BackColor = System.Drawing.Color.Transparent;
            this.digitalClock1.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.digitalClock1.Location = new System.Drawing.Point(633, 278);
            this.digitalClock1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.digitalClock1.Name = "digitalClock1";
            this.digitalClock1.Size = new System.Drawing.Size(103, 44);
            this.digitalClock1.TabIndex = 0;
            // 
            // FrmDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(743, 325);
            this.Controls.Add(this.itemPanel1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmDashboard";
            this.itemPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.ItemPanel itemPanel1;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem1;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem2;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem3;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem4;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem5;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem6;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem7;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem8;
        private DevComponents.DotNetBar.Metro.MetroTileItem metroTileItem9;
        private DigitalClock.DigitalClock digitalClock1;
    }
}