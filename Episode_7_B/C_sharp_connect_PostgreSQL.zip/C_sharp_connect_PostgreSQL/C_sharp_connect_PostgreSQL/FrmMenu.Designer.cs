﻿namespace C_sharp_connect_PostgreSQL
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._Left_Menu = new System.Windows.Forms.Panel();
            this._Menu_table = new System.Windows.Forms.TableLayoutPanel();
            this._Left_Menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // _Left_Menu
            // 
            this._Left_Menu.Controls.Add(this._Menu_table);
            this._Left_Menu.Cursor = System.Windows.Forms.Cursors.Hand;
            this._Left_Menu.Dock = System.Windows.Forms.DockStyle.Left;
            this._Left_Menu.Location = new System.Drawing.Point(0, 0);
            this._Left_Menu.Name = "_Left_Menu";
            this._Left_Menu.Size = new System.Drawing.Size(174, 569);
            this._Left_Menu.TabIndex = 0;
            // 
            // _Menu_table
            // 
            this._Menu_table.ColumnCount = 1;
            this._Menu_table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this._Menu_table.Dock = System.Windows.Forms.DockStyle.Fill;
            this._Menu_table.Location = new System.Drawing.Point(0, 0);
            this._Menu_table.Name = "_Menu_table";
            this._Menu_table.RowCount = 1;
            this._Menu_table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this._Menu_table.Size = new System.Drawing.Size(174, 569);
            this._Menu_table.TabIndex = 0;
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(68)))));
            this.ClientSize = new System.Drawing.Size(942, 569);
            this.Controls.Add(this._Left_Menu);
            this.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Name = "FrmMenu";
            this.Text = "FrmMenu";
            this.Load += new System.EventHandler(this.FrmMenu_Load);
            this._Left_Menu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel _Left_Menu;
        private System.Windows.Forms.TableLayoutPanel _Menu_table;
    }
}