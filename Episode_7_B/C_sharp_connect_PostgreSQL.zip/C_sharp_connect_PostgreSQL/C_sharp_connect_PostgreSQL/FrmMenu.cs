﻿using C_sharp_connect_PostgreSQL.Class;
using NpgsqlTypes;
using PRO_QR.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_sharp_connect_PostgreSQL
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void FrmMenu_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            Line_Menu();
        }

        Connectionsql sql = new Connectionsql();
        private Color _buttonColor = Color.SeaShell;
        string vMenuID = string.Empty;
        private void Line_Menu()
        {
            try
            {
                DataTable dt = new DataTable();

                List<pgParameter> p = new List<pgParameter>
                {
                    new pgParameter(){name="profile",npgqtyp=NpgsqlDbType.Char,value="" }
                };

                sql.ExecuteProc("proc_get_menu", p, out dt);

                int vNum = dt.Rows.Count;
                // Create image.
                Image newImage = null;
                Button_small[] listitem = new Button_small[vNum];
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    try
                    {
                        if (File.Exists(Application.StartupPath + @"\Resource\Menu\" + dt.Rows[i]["lin_id"].ToString() + ".png"))
                        {
                            newImage = Image.FromFile(Application.StartupPath + @"\Resource\Menu\" + dt.Rows[i]["lin_id"].ToString() + ".png");
                        }
                        else
                        {
                            newImage = Image.FromFile(Application.StartupPath + @"\Resource\Menu\No.png");
                        }

                    }
                    catch { }

                    listitem[i] = new Button_small();
                    listitem[i].lblMessage.Name = dt.Rows[i]["lin_id"].ToString();
                    listitem[i].lblTitle.Name = dt.Rows[i]["lin_id"].ToString();
                    listitem[i]._Pic.Name = dt.Rows[i]["lin_id"].ToString();

                    listitem[i].Name = dt.Rows[i]["lin_id"].ToString();

                    listitem[i].Title = dt.Rows[i]["lin_name"].ToString();
                    listitem[i].Message = dt.Rows[i]["lin_id"].ToString();
                    listitem[i].BackColor = Color.Brown;
                    listitem[i].Icon = newImage;

                    listitem[i].lblTitle.ForeColor = Color.White;
                    listitem[i].lblMessage.ForeColor = Color.White;
                    listitem[i].BackColor = Color.OliveDrab;

                    _Menu_table.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
                    _Menu_table.Controls.Add(listitem[i]);

                    listitem[i].Click += new System.EventHandler(this.Action_Click);
                    listitem[i]._Pic.Click += new System.EventHandler(this.Action_Click);
                    listitem[i].lblTitle.Click += new System.EventHandler(this.Action_Click);
                    listitem[i].lblMessage.Click += new System.EventHandler(this.Action_Click);
                    listitem[i].PanBox.Click += new System.EventHandler(this.Action_Click);

                }

                TableLayoutRowStyleCollection styles = this._Menu_table.RowStyles;
                foreach (RowStyle style in styles)
                {
                    if (style.SizeType == SizeType.Absolute)
                    {
                        style.SizeType = SizeType.AutoSize;
                        style.Height = 50;
                    }
                    else if (style.SizeType == SizeType.AutoSize)
                    {
                        style.SizeType = SizeType.Percent;
                        style.Height = 50;
                    }
                    else
                    {
                        // Set the row height to 50 pixels.
                        style.SizeType = SizeType.AutoSize;
                        style.Height = 50;
                    }
                }


            }
            catch { }
        }

        private void Action_Click(object sender, EventArgs e)
        {
            try
            {
                string vMenuID = string.Empty;
                if (sender is TextBox)
                {
                    TextBox obj = (TextBox)sender;
                    vMenuID = obj.Name;
                }
                else if (sender is Label)
                {
                    Label obj = (Label)sender;
                    vMenuID = obj.Name;
                }
                else if (sender is PictureBox)
                {
                    PictureBox obj = (PictureBox)sender;
                    vMenuID = obj.Name;
                }
                else
                {
                    Button_small obj = sender as Button_small;
                    vMenuID = obj.Name;
                }
                GetControlByName(_Menu_table, vMenuID);

            }
            catch { }
        }

        public Control GetControlByName(Control ParentCntl, string NameToSearch)
        {
            if (ParentCntl.Name == NameToSearch)
                return ParentCntl;
            foreach (Control ChildCntl in ParentCntl.Controls)
            {

                if (ChildCntl is Button_small)
                {
                    ChildCntl.BackColor = Color.OliveDrab;
                }

                Control ResultCntl = GetControlByName(ChildCntl, NameToSearch);
                if (ResultCntl != null)
                {
                    ResultCntl.BackColor = Color.Red;
                }
            }
            return null;
        }



    }
}
