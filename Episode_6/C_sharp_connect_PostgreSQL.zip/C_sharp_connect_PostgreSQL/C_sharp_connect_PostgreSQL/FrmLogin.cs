﻿using C_sharp_connect_PostgreSQL.Class;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_sharp_connect_PostgreSQL
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        Connectionsql sql = new Connectionsql();

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {
            txtUserName.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtUserName.Focus();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtUserName.Text.Trim() == string.Empty || txtPassword.Text.Trim() == string.Empty)
                {
                    MessageBox.Show("Invalid Username and password , Plz input !", "Invalid Username and password , Plz input !", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    DataTable dt = new DataTable();

                    List<pgParameter> p = new List<pgParameter>
                    {
                        new pgParameter(){name="usernam",npgqtyp=NpgsqlDbType.Char,value=txtUserName.Text.Trim() },
                        new pgParameter(){name="userpwd",npgqtyp=NpgsqlDbType.Char,value=txtPassword.Text.Trim() }

                    };

                    sql.ExecuteProc("proc_user_login", p, out dt);

                    if (dt.Rows.Count > 0)
                    {
                        this.Hide();
                        FrmMain frm = new FrmMain();
                        frm.Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Username and password , Plz try again !", "Invalid Username and password , Plz try again !", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch { }
        }
    }
}
