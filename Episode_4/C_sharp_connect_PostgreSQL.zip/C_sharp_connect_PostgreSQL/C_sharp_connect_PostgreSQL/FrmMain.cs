﻿using C_sharp_connect_PostgreSQL.Class;
using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_sharp_connect_PostgreSQL
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        

        private void FrmMain_Load(object sender, EventArgs e)
        {

        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            DataTable dtgetdata = new DataTable();

            Connectionsql conSql = new Connectionsql();

            conSql.ReadXml(Application.StartupPath + "\\connection.xml");

            dtgetdata = conSql.getdata("select *from tblstudent;");

            dgData.DataSource = dtgetdata;
        }
    }
}
