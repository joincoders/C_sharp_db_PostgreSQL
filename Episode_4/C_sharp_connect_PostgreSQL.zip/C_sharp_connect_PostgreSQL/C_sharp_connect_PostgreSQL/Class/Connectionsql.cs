﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace C_sharp_connect_PostgreSQL.Class
{
    class Connectionsql
    {
        string vStrConneciton = string.Empty;

        NpgsqlConnection vCon;
        NpgsqlCommand vCmd;

        public static string v_server = string.Empty;
        public static string v_port = string.Empty;
        public static string v_username = string.Empty;
        public static string v_password = string.Empty;
        public static string v_dbname = string.Empty;

        public string ReadXml(string Part)
        {

            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(Part);

            XmlNode Node;
            Node = xmldoc.DocumentElement;

            foreach (XmlNode n in Node.ChildNodes)
            {
                if (n.Name == "server")
                {
                    v_server = n.InnerText;
                } else if (n.Name == "port")
                {
                    v_port = n.InnerText;
                }
                else if (n.Name == "user")
                {
                    v_username = n.InnerText;
                }
                else if (n.Name == "password")
                {
                    v_password = n.InnerText;
                }
                else if (n.Name == "dbname")
                {
                    v_dbname = n.InnerText;
                }


            }

            vStrConneciton = "Server="+ v_server + "; port="+ v_port + " ; user id="+ v_username + "; password="+ v_password + "; database="+ v_dbname + " ; ";

            return vStrConneciton;

        }

        private void connection()
        {
            vCon = new NpgsqlConnection();
            vCon.ConnectionString = vStrConneciton;
            if (vCon.State == ConnectionState.Closed)
            {
                vCon.Open();
            }
        }

        public DataTable getdata(string sql)
        {
            DataTable dt = new DataTable();
            connection();
            vCmd = new NpgsqlCommand();
            vCmd.Connection = vCon;
            vCmd.CommandText = sql;

            NpgsqlDataReader dr = vCmd.ExecuteReader();
            dt.Load(dr);
            return dt;
        }
    }
}
